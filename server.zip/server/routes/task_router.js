const express =require('express')
const Task =require('../models/task.js')

const router = new express.Router()

// we will pass string as an argument to this ObjectID funtion and it will retrun objcect id
// this is useful when we are accepting the object id for mapping to database in request

var ObjectID = require('mongodb').ObjectID;

// this is the post request
// async means in this function we are calling some actvities which takes more time to execute

router.post('/task',async(req,res)=>
{
    var task=new Task(req.body)

   
   try {
    console.log(task)
    // awit return the promis and the data from database as well
    // untill this line execute the next line canot be executed
    // this makes the function synchronous (which execute line by line which is not skip and e
  //  execute later by compiler)
  
    await task.save()
    res.status(201).send('task saved successfully')
 
   } catch (error) {
    res.status(500).send(e)

   }
})

router.get('/task_list',async(req,res)=>
{
        console.log('req',req)
        try {
            // this function returns the data from database
            const data= await Task.find({}).sort({"createdAt":1})
            res.status(201).send(data)
            console.log(data)
        } catch (e) {
            res.status(500).send(e)
            console.log(e)
        }
        
})

// for mongoose have various funcntions for model

module.exports=router