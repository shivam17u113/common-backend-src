const mongoose =require('mongoose')
const validator =require('validator')
// we are creating the schema to map the objects coming from client or to send to server

// this contains the field with their validation which are coming or sending to server

const taskSchema =  new mongoose.Schema({

    // it is the  fild in object
    title:{
        type:String,
        trim:true,
        required:true
    },
    done:{
        type :Boolean,
        default:false
    }
},{
    timestamps:true
})

const Task =mongoose.model('Task',taskSchema)

// we atre exporting the shema to use in another file
module.exports=Task